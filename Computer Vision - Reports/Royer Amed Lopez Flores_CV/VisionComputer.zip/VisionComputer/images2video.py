from ctypes import sizeof
from fileinput import filename
import os
import cv2
import numpy as np
path='./salida3'#capeta del robotDetectado
#path= './salida6'#carpeta final
frames = os.listdir(path)

height ,width, layers = cv2.imread(path+'/'+frames[0]).shape
size = (width,height)
#out = cv2.VideoWriter('./velocidadRobotFactordeReproducción.avi',cv2.VideoWriter_fourcc(*'mp4v'),60,size)
#out = cv2.VideoWriter('./velocidadRobot.avi',cv2.VideoWriter_fourcc(*'mp4v'),60,size)
out = cv2.VideoWriter('./DecteciondRobot.avi',cv2.VideoWriter_fourcc(*'mp4v'),60,size)

factor = 1
for i in range(len(frames)):
    dirFile = path + '/frame'+str(i)+'.jpg'
    im = cv2.imread(dirFile)
    print(dirFile)
    for i in range(factor):
        out.write(im)
out.release()
