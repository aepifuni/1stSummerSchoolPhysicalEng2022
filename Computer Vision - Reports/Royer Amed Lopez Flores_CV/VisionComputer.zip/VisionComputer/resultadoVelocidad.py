import cv2 
import pandas as pd
import numpy as np
f = open('salida.csv','r')
resul = pd.read_csv("salida.csv")
resul = pd.DataFrame(resul).to_numpy()
ubicacion = (80,160)
font = cv2.FONT_HERSHEY_SIMPLEX
tamañoLetra = 0.5
colorLetra = (221,82,196)
grosorLetra = 2

#Escribir texto


for i in range(60):
    im = cv2.imread('./salida5/frame'+str(i)+'.jpg')
    linea1 = 'px:'+str(resul[i][1]+249)+'cm'
    linea2 = ' vx:'+str(resul[i][3]/100)+'cm'
    linea3 = 'py:'+str(resul[i][0]+69)+'m/s'
    linea4 = ' vy:'+str(resul[i][2]/100)+'m/s'
    cv2.putText(im, linea1, ubicacion, font, tamañoLetra, colorLetra, grosorLetra)
    cv2.putText(im, linea2, (80,180), font, tamañoLetra, colorLetra, grosorLetra)
    cv2.putText(im, linea3, (80,200), font, tamañoLetra, colorLetra, grosorLetra)
    cv2.putText(im, linea4, (80,220), font, tamañoLetra, colorLetra, grosorLetra)
    
    cv2.imwrite('./salida6/frame'+str(i)+'.jpg',im)
